import torch
import torch.nn as nn
import torch.nn.functional as F


class AttentionHead(nn.Module):
    
    def __init__(self, in_channels : int, context_size : int, head_size : int, droprate : float = 0.2, device : str = 'cpu') -> None:
        super().__init__()
        
        self.key = nn.Linear(in_channels, head_size, bias = False, device = device)
        self.query = nn.Linear(in_channels, head_size, bias = False, device = device)
        self.value = nn.Linear(in_channels, head_size, bias = False, device = device)
        
        self.t = context_size
        self.hs = head_size
        self.device = device
        
        self.register_buffer('mask', torch.tril(torch.ones(self.t, self.t, device = device)))
        self.dropout = nn.Dropout(droprate)
    
    def to(self, device : str):
        val = super().to(device)
        self.mask = self.mask.to(device)
        self.key = self.key.to(device)
        self.query = self.query.to(device)
        self.value = self.value.to(device)
        self.device = device
        return val
    
    def forward(self, x):
        x # b t c
        
        b, t, c = x.shape
        
        k = self.key(x) # b t hs
        q = self.query(x) # b t hs
        
        weights = q @ k.transpose(-2, -1) * (c ** -0.5) # b t hs @ b hs t = b t t
        weights = weights.masked_fill(self.mask[:t, :t] == 0, float('-inf'))
        weights = F.softmax(weights, dim = -1)
        weights = self.dropout(weights)
        
        v = self.value(x) # b t hs
        out = weights @ v # b t t @ b t hs = b t hs
        
        return out
        


class ParallelAttentionHead(nn.Module):
    
    def __init__(self, in_channels : int, context_size : int, head_size : int, nheads : int, droprate : float = 0.2, device : str = 'cpu') -> None:
        super().__init__()
        
        self.heads = []
        for _ in range(nheads):
            self.heads.append(
                AttentionHead(
                    in_channels=in_channels,
                    context_size=context_size,
                    head_size = head_size // nheads,
                    droprate = droprate,
                    device = device
                )
            )
        self.heads = nn.ModuleList(self.heads)
        self.dropout = nn.Dropout(droprate)
        self.projector = nn.Linear(head_size, in_channels, device = device)
        self.norm = nn.LayerNorm(in_channels, device = device)
        
    
    def to(self, device : str):
        val = super().to(device)
        self.projector = self.projector.to(device)
        self.norm = self.norm.to(device)
        for i, each in enumerate(self.heads):
            self.heads[i] = each.to(device)
        return val
    
    def forward(self, x):
        x # b t c
        # out = self.norm(x)
        out = torch.concat(list(map( lambda head : head(x), self.heads )), dim = -1)
        out = self.dropout(self.projector(out)) # b t c
        # out = out + x
        return out
        



class FFN(nn.Module):
    
    def __init__(self, in_channels : int, efactor : int = 4, droprate : float = 0.2, device : str = 'cpu') -> None:
        super().__init__()
        
        self.norm = nn.LayerNorm(in_channels, device = device)
        
        self.ffn = nn.Sequential(
            nn.Linear(in_channels, efactor * in_channels, device = device),
            nn.ReLU(),
            nn.Linear(efactor * in_channels, in_channels, device = device),
            nn.Dropout(droprate),
        )
        
        self.device = device
    
    def to(self, device : str):
        val = super().to(device)
        self.ffn = self.ffn.to(device)
        self.norm = self.norm.to(device)
        return val
    
    
    def forward(self, x : torch.Tensor) -> torch.Tensor:
        x # b t c
        # out = self.norm(x)
        out = self.ffn(x) # b t c
        # out = x + out
        return out


class Block(nn.Module):
    
    def __init__(
            self,
            in_channels : int,
            context_size : int,
            head_size : int,
            nheads : int,
            droprate : float = 0.2,
            device : str = 'cpu',
        ) -> None:
        super().__init__()
        
        self.att = ParallelAttentionHead(
            in_channels = in_channels,
            context_size= context_size,
            head_size = head_size,
            nheads = nheads,
            droprate = droprate,
            device = device
        )
        
        self.attln = nn.LayerNorm(in_channels, device = device)
        
        self.ffn = FFN(
            in_channels = in_channels,
            efactor = 4,
            droprate = droprate,
            device = device
        )
        
        self.ffnln = nn.LayerNorm(in_channels, device = device)
        
    
    def to(self, device : str):
        val = super().to(device)
        self.att = self.att.to(device)
        self.ffn = self.ffn.to(device)
        self.ffnln = self.ffnln.to(device)
        self.attln = self.attln.to(device)
        return val
    
    def forward(self, x):
        x #b t c
        x = x + self.att(self.attln(x))
        x = x + self.ffn(self.ffnln(x))
        return x




def position_embedding(context_size : int, d_embed : int, N : int = 1e+4, device : str = 'cpu') -> torch.Tensor:
    embs = torch.arange(0, d_embed // 2, 1)
    embs = torch.unsqueeze(embs, -1)
    embs = torch.tile(embs, (1,2))
    embs = torch.flatten(embs)
    embs = torch.unsqueeze(embs, -1)
    embs = torch.tile(embs, (1, context_size))
    
    embs = embs * (2 / d_embed)
    embs = torch.pow(N, -embs)
    
    for each in range(context_size):
        embs[:, each] *= each
    
    for each in range(d_embed):
        if each % 2: embs[each] = torch.cos(embs[each])
        else: embs[each] = torch.sin(embs[each])
    
    embs = embs.to(device)
    return embs.T





class Transformer(nn.Module):
    
    def __init__(
            self, 
            vsize : int,
            d_embed : int,
            context_size : int,
            nblocks : int,
            head_size : int,
            nheads : int,
            droprate : float = 0.2,
            device : str = 'cpu',
        ) -> None:
        super().__init__()
        
        self.token_embedder = nn.Embedding(vsize, d_embed, device = device)
        # self.position_embedder = nn.Embedding(context_size, d_embed, device = device)
        self.device = device
        
        self.blocks = [
            Block(
                in_channels = d_embed,
                context_size = context_size,
                head_size = head_size,
                nheads = nheads,
                droprate = droprate,
                device = device
            ) for each in range(nblocks)
        ]
        
        self.blocks = nn.Sequential(*self.blocks)
        
        self.norm = nn.LayerNorm(d_embed, device = device)
        self.unembedder= nn.Linear(d_embed, vsize, device=device)
        
        self.context_size = context_size
        self.d_embed = d_embed
        
    
    
    def to(self, device : str):
        val = super().to(device)
        self.token_embedder = self.token_embedder.to(device)
        # self.position_embedder = self.position_embedder.to(device)
        self.norm = self.norm.to(device)
        self.unembedder = self.unembedder.to(device)
        self.blocks = self.blocks.to(device)
        self.device = device
        return val
    
    
    def forward(self, inputs : torch.Tensor, debug : bool = False) -> torch.Tensor:
        b, t = inputs.shape
        
        # tokens = self.token_embedder(inputs) + self.position_embedder(torch.arange(t, device=self.device))
        tokens = self.token_embedder(inputs) + position_embedding(t, self.d_embed, device=self.device)
        if debug: print(tokens.shape)
        tokens = self.blocks(tokens)
        if debug: print(tokens.shape)
        tokens = self.norm(tokens)
        if debug: print(tokens.shape)
        tokens = self.unembedder(tokens)
        if debug: print(tokens.shape)
        return tokens
    
    
    def generate_tokens(self, seed : torch.Tensor, max_tokens : int = 2000) -> torch.Tensor:
        
        tokens = seed # b n
        
        for each in range(max_tokens):
            print(f'Generating token {each+1}/{max_tokens}...', end = '\r')
            
            tokensub = tokens[:, -self.context_size:] # b t (last t)
            
            logits = self(tokensub) # b t vsize
            
            logits = logits[:, -1, :] # b -1 vsize = b vsize
            
            probs = F.softmax(logits, dim = -1) # b vsize
            
            pred = torch.multinomial(probs, num_samples = 1) # b 1
            
            tokens = torch.concat((tokens, pred), dim = 1)
            
        
        print()
        return tokens
    
    
    
    
