import torch
import torch.nn as nn
import torch.nn.functional as F
import pickle
import matplotlib.pyplot as plt

from typing import Callable
from arch import *


def read_data(folder : str) -> str:
    #Join all books' text into one:
    rawtext = ''
    for each in range(1, 8):
        with open(f'{folder}/hp{each}.txt', 'r', encoding = 'utf-8') as file:
            rawtext = file.read().strip()
    return rawtext

def tokenise(rawtext : str) -> list[str]:
    # Split by newline, join back with spaces
    rawtext = ' '.join(rawtext.split('\n'))
    
    #Deal with all the special characters that might be in the text
    for each in "()[]!?.,{}'\"-;:…_=+":
        rawtext = f' {each} '.join(rawtext.split(each))
    
    # Split into words
    rawtext = rawtext.split(' ') 
    print('Total no. of tokens in text: ', len(rawtext))
    
    #Convert all words to lower case:
    rawtext = list(map( lambda x: x.strip().lower(), rawtext))
    
    return rawtext

def make_encoding(tokens : list[str]) -> tuple[dict[str, int], dict[int, str]]:
    #Get all unique tokens:
    uniques = list(set(tokens))
    uniques.sort()
    print('Unique tokens in text: ', len(uniques))
    
    encoding, decoding = dict(), dict()
    
    #encoding and decoding based on index values
    for i, each in enumerate(uniques):
        encoding[each] = i
        decoding[i] = each
    
    return encoding, decoding


def load_text(
        encodingfile : str = None, folder : str = 'hp_data', device : str = 'cpu'
    ) -> tuple[torch.TensorType, int, Callable[[str], list[int]], Callable[[list[int]], str]]:
    fulltext = read_data(folder)
    
    if encodingfile is None:
        uniques = list(set(list(fulltext)))
        encoder = dict()
        decoder = dict()
        for i, each in enumerate(uniques):
            encoder[each] = i
            decoder[i] = each
        with open('encoding.enc', 'wb') as file:
            pickle.dump((uniques, encoder, decoder), file)
    else:
        with open(encodingfile, 'rb') as file:
            uniques, encoder, decoder = pickle.load(file)
    
    
    fulldata = torch.tensor([encoder[x] for x in list(fulltext)], dtype = torch.long, device = device)
    
    return fulldata, len(uniques), encoder, decoder
    






def get_batch(data : torch.Tensor, batch_size : int = 4, context_size : int = 8, device = 'cpu', expand : bool = False) -> tuple[torch.Tensor, torch.Tensor]:
    length = data.shape[0]
    
    
    starts = torch.randint(length - context_size - 1, (batch_size,))
    bx = [data[each : each + context_size] for each in starts]
    by = [data[each + 1 : each + 1 + context_size] for each in starts]
    
    batchx = torch.stack(bx).to(device)
    batchy = torch.stack(by).to(device)
    
    
    if expand:
        batchx = batchx.unsqueeze(-1)
        batchy = batchy.unsqueeze(-1)
    
    return batchx, batchy








@torch.no_grad()
def estimate_loss(model : nn.Module, data : torch.Tensor, batch_size : int, context_size : int, device : str = 'cpu', iters : int = 100):
    out = None
    model.eval()
    # for split in ['train', 'val']:
    losses = torch.zeros(iters, device = device)
    for k in range(iters):
        X, Y = get_batch(data, batch_size, context_size, device)
        ycap = model(X)
        b, t, c = ycap.shape
        loss = F.cross_entropy(ycap.view(b * t, c), Y.view(b * t))
        losses[k] = loss.item()
        print(f'\tEval iter {k+1}/{iters}...', end = '\r')
    out = losses.mean().item()
    model.train()
    print()
    return out


def train_transformer(
        data : torch.Tensor, 
        model : nn.Module,
        lr : float = 1e-3,
        batch_size : int = 32, 
        context_size : int = 8, 
        epochs : int = 10, 
        steps : int = 500,
        eval_iters : int = 100,
        device : str = 'cpu',
    ) -> list[float]:
    
    timeline = {
        'train' : [],
        'eval' : []
    }
    
    model.train()
    
    adam = torch.optim.AdamW(model.parameters(), lr = lr)
    
    for epoch in range(epochs):
        print(f'Epoch {epoch + 1}:')
        # l = estimate_loss(model, data, batch_size, context_size, device, eval_iters)
        # timeline['eval'].append(l)
        for each in range(steps):
            xb, yb = get_batch(data, batch_size, context_size, device)
            
            ycap = model(xb)
            
            b, t, c = ycap.shape
            
            loss = F.cross_entropy(ycap.view(b * t, c), yb.view(b * t))
            # l = loss.item()
            
            # model.zero_grad()
            adam.zero_grad()
            loss.backward()
            adam.step()
            
            print(f'\tStep {each + 1}/{steps} : {loss.item():.5f}', end = '\r')
            timeline['train'].append(loss.item())
        print()
        l = estimate_loss(model, data, batch_size, context_size, device, eval_iters)
        timeline['eval'].append(l)
        print(f'\n\tEval loss : {l:.5f}')
        print()
    
    model.eval()
    return timeline




if __name__ == '__main__':
    
    if torch.cuda.is_available(): print('CUDA is working...')
    else: print('CUDA NOT FOUND...')
    
    fulldata, uniques, encoder, decoder = load_text()
    
    context_size = 64
    
    gpt = Transformer(
        vsize = uniques,
        d_embed = 256,
        context_size = context_size,
        nblocks = 6,
        head_size = 64,
        nheads = 8,
        droprate = 0.25
    )
    
    # x, y = get_batch(fulldata, context_size = 32)
    
    # gpt.forward(x, True)
    
    # exit(0)
    
    
    # gpt : Transformer = torch.load('gpt.pth')
    
    gpt = gpt.to('cuda')
    
    print(sum([sum([x.numel() for x in each.parameters()]) for each in gpt.blocks])/1e6, 'M parameters')
    
    # exit(0)
    
    timeline = train_transformer(
        fulldata, gpt, 
        device = 'cuda',
        batch_size = 16 * 2 * 2,
        context_size = context_size,
        epochs = 50,
        steps = 100,
    )
    
    torch.save(gpt, 'gpt.pth')
    
    
    fig, ax = plt.subplots(1, 2, figsize = (12, 5))
    ax[0].plot(timeline['train'])
    ax[0].set_title('train')
    ax[1].plot(timeline['eval'])
    ax[1].set_title('eval')
    plt.show()
    
    
    
    # inputs = torch.tensor([encoder('This is a piece of input string guys')], dtype = torch.long, device='cuda')
    
    # preds = gpt.generate_tokens(inputs)
    
    # print(decoder(preds[0].tolist()))