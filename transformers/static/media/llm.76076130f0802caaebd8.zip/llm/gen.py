import torch
import torch.nn as nn
import torch.nn.functional as F
import pickle

from typing import Callable
from arch import *






model : Transformer = torch.load('gpt.pth')
model = model.to('cuda')

with open('encoding.enc', 'rb') as file:
    _, encoder, decoder = pickle.load(file)

prompt = input('Enter a prompt: ')
prompt = prompt.strip()
prompt = [encoder[x] for x in list(prompt)]

gen = model.generate_tokens(torch.tensor([prompt], dtype = torch.long, device = 'cuda'), 1000)
gen = ''.join([decoder[x] for x in gen[0].tolist()])

with open('output.txt', 'w') as file:
    file.write(gen)

print("Generated:\n")
print(gen)

